# Changelog 1.1.0

## Dark mine upgrade 1

### Weapons animation
* **Pickaxe animation**

### Objects & Decor
* **Rails**
* **Animated Carts**
* **Various rocks and metal nodes**
* **Full cart**
* **Lantern**
* **Wooden beam**
* **Pickaxe**
* **Mushrooms**

### Pickup items:
* **Metal bar**
* **Metal nugget**

## Small Fix and updates
* **Filename update**: objects > props
* **Removed raw files**: removed raw aseprite files
* **Toxic sewer tileset**: small fix on right walls and corner.
* **Slime**: small update of the moving animation.

